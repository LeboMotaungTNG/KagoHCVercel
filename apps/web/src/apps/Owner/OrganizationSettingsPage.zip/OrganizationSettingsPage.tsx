import React, { useState, useEffect } from "react";
import { 
  Container, Row, Col, Card, CardBody, Button, Input, Label, 
  FormGroup, Table, Spinner, Badge, Alert, Modal, ModalHeader, 
  ModalBody, ModalFooter, Form 
} from "reactstrap";
import { 
  FaSave, FaEdit, FaPlus, FaTrash, FaChevronDown, FaChevronRight, 
  FaBuilding, FaMoneyBillWave, FaCalendarAlt, FaCloudUploadAlt, 
  FaCalculator, FaCheckCircle, FaExclamationTriangle 
} from "react-icons/fa";

const API_URL = import.meta.env.VITE_API_URL || "https://employee-evaluation-kago-e63baae4d822.herokuapp.com/api/v1";

// ============================================
// COMPANY DETAILS TAB (ENHANCED VERSION - FIXED)
// ============================================
const CompanyDetailsTab = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [companyData, setCompanyData] = useState({
    // Basic Information
    name: "Kago Human Capital",
    size: 45,
    sector: "Technology",
    email: "info@kagohc.com",
    phone: "+27 11 123 4567",
    alternativePhone: "+27 11 123 4568",
    website: "www.kagohc.com",
    fax: "+27 11 123 4569",
    
    // Registration & Legal
    taxId: "1234567890",
    registrationNumber: "2020/123456/07",
    vatNumber: "4123456789",
    uifReference: "UIF123456789",
    sdlReference: "SDL123456789",
    workInjuryFundRef: "WIF123456789",
    
    // Banking Information
    bank: {
      bankName: "First National Bank",
      accountName: "Kago Human Capital",
      accountNumber: "62812345678",
      branchCode: "250655",
      accountType: "Business Cheque",
      swiftCode: "FIRNZAJJ"
    },
    
    // Contact Persons
    contacts: {
      ceo: {
        name: "Thabo Mbeki",
        email: "thabo@kagohc.com",
        phone: "+27 82 123 4567"
      },
      finance: {
        name: "Naledi Dlamini",
        email: "naledi@kagohc.com",
        phone: "+27 83 123 4567"
      },
      payroll: {
        name: "Peter Petersen",
        email: "peter@kagohc.com",
        phone: "+27 84 123 4567"
      }
    },
    
    // Address
    address: {
      street: "123 Business Park",
      city: "Johannesburg",
      state: "Gauteng",
      country: "South Africa",
      postalCode: "2196",
      physicalAddress: "123 Business Park, Sandton, Johannesburg",
      postalAddress: "PO Box 1234, Sandton, 2196"
    },
    
    // Business Classification
    businessType: "Private Company",
    yearsInOperation: 8,
    
    // SARS & Tax Information
    sarsBranch: "Sandton",
    incomeTaxNumber: "9876543210",
    payeReference: "PAYE123456789",
    provisionalTaxpayer: true,
    taxComplianceStatus: "Compliant",
    
    // Additional Settings
    language: "English",
    timezone: "Africa/Johannesburg",
    dateFormat: "DD/MM/YYYY",
    fiscalYearStart: "2025-03-01",
    fiscalYearEnd: "2026-02-28",
    
    // Status
    status: "Active",
    verified: true,
    lastAuditDate: "2025-01-15"
  });

  const [formData, setFormData] = useState(companyData);

  // Fetch company data from API on component mount
  useEffect(() => {
    const fetchCompanyData = async () => {
      setIsLoading(true);
      try {
        const token = localStorage.getItem("token");
        const response = await fetch(`${API_URL}/owner/company/settings`, {
          headers: { "Authorization": `Bearer ${token}` }
        });
        const data = await response.json();
        if (data.success && data.data) {
          // Merge API data with defaults to ensure all nested objects exist
          const mergedData = {
            ...companyData,
            ...data.data,
            bank: { ...companyData.bank, ...data.data.bank },
            contacts: { ...companyData.contacts, ...data.data.contacts },
            address: { ...companyData.address, ...data.data.address }
          };
          setCompanyData(mergedData);
          setFormData(mergedData);
        }
      } catch (error) {
        console.error("Error fetching company data:", error);
        // Keep using default mock data on error
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchCompanyData();
  }, []);

  const handleSave = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`${API_URL}/owner/company/settings`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      });
      
      if (response.ok) {
        setCompanyData(formData);
        setIsEditing(false);
        alert("Company details saved successfully!");
      } else {
        alert("Error saving company details");
      }
    } catch (error) {
      console.error("Error saving company data:", error);
      alert("Error saving company details");
    }
  };

  // Helper function to get nested value
  const getNestedValue = (obj: any, path: string): any => {
    return path.split('.').reduce((current, part) => current?.[part], obj);
  };

  // Helper function to set nested value
  const setNestedValue = (obj: any, path: string, value: any): any => {
    const parts = path.split('.');
    const newObj = { ...obj };
    let current = newObj;
    for (let i = 0; i < parts.length - 1; i++) {
      current[parts[i]] = { ...current[parts[i]] };
      current = current[parts[i]];
    }
    current[parts[parts.length - 1]] = value;
    return newObj;
  };

  // Helper function to render editable fields
  const renderField = (label: string, value: any, fieldPath: string, type: "text" | "email" | "number" | "date" | "checkbox" | "select" | "textarea" = "text") => {
    const currentValue = getNestedValue(formData, fieldPath) || "";
    
    return (
      <Col md={6} key={fieldPath}>
        <Label style={{ fontWeight: 600 }}>{label}</Label>
        {isEditing ? (
          type === "textarea" ? (
            <textarea 
              rows={3}
              value={currentValue} 
              onChange={(e) => setFormData(setNestedValue(formData, fieldPath, e.target.value))}
              style={{ width: "100%", padding: "8px 12px", borderRadius: "6px", border: "1px solid #CBD5E0", fontSize: "14px", resize: "vertical", minHeight: "80px" }}
              className="form-control"
            />
          ) : type === "number" ? (
            <Input 
              type="number" 
              value={currentValue} 
              onChange={(e) => setFormData(setNestedValue(formData, fieldPath, parseInt(e.target.value) || 0))}
            />
          ) : type === "date" ? (
            <Input 
              type="date" 
              value={currentValue} 
              onChange={(e) => setFormData(setNestedValue(formData, fieldPath, e.target.value))}
            />
          ) : type === "checkbox" ? (
            <input 
              type="checkbox" 
              checked={currentValue === true || currentValue === "true"} 
              onChange={(e) => setFormData(setNestedValue(formData, fieldPath, e.target.checked))}
              style={{ width: "auto", marginTop: "8px" }}
              className="form-check-input"
            />
          ) : type === "select" ? (
            <select 
              value={currentValue} 
              onChange={(e) => setFormData(setNestedValue(formData, fieldPath, e.target.value))}
              style={{ width: "100%", padding: "8px 12px", borderRadius: "6px", border: "1px solid #CBD5E0", fontSize: "14px" }}
              className="form-control"
            >
              {label === "Business Type" && (
                <>
                  <option>Private Company (Pty Ltd)</option>
                  <option>Public Company (Ltd)</option>
                  <option>Non-Profit Organisation</option>
                  <option>Trust</option>
                  <option>Partnership</option>
                  <option>Sole Proprietorship</option>
                  <option>State-Owned Entity</option>
                  <option>Co-operative</option>
                </>
              )}
              {label === "Sector/Industry" && (
                <>
                  <option>Technology & Software</option>
                  <option>Finance & Banking</option>
                  <option>Healthcare & Medical</option>
                  <option>Manufacturing</option>
                  <option>Retail & E-commerce</option>
                  <option>Education & Training</option>
                  <option>Construction & Engineering</option>
                  <option>Transportation & Logistics</option>
                  <option>Human Capital & Recruitment</option>
                </>
              )}
              {label === "Language" && (
                <>
                  <option>English</option>
                  <option>Afrikaans</option>
                  <option>isiZulu</option>
                  <option>isiXhosa</option>
                  <option>Sepedi</option>
                  <option>Setswana</option>
                  <option>Other</option>
                </>
              )}
              {label === "Timezone" && (
                <>
                  <option>Africa/Johannesburg</option>
                  <option>Africa/Cape Town</option>
                  <option>Africa/Durban</option>
                </>
              )}
              {label === "Date Format" && (
                <>
                  <option>DD/MM/YYYY</option>
                  <option>MM/DD/YYYY</option>
                  <option>YYYY-MM-DD</option>
                </>
              )}
              {label === "Account Type" && (
                <>
                  <option>Business Cheque</option>
                  <option>Business Savings</option>
                  <option>Business Current</option>
                </>
              )}
              {label === "Status" && (
                <>
                  <option>Active</option>
                  <option>Inactive</option>
                  <option>Suspended</option>
                  <option>Pending Verification</option>
                </>
              )}
              {label === "Bank Name" && (
                <>
                  <option>ABSA Bank</option>
                  <option>First National Bank (FNB)</option>
                  <option>Standard Bank</option>
                  <option>Nedbank</option>
                  <option>Capitec Bank</option>
                  <option>Discovery Bank</option>
                </>
              )}
              {label === "SARS Branch" && (
                <>
                  <option>Sandton</option>
                  <option>Pretoria</option>
                  <option>Cape Town</option>
                  <option>Durban</option>
                  <option>Port Elizabeth</option>
                </>
              )}
              {label === "Tax Compliance Status" && (
                <>
                  <option>Compliant</option>
                  <option>Pending</option>
                  <option>Non-Compliant</option>
                  <option>Under Review</option>
                </>
              )}
            </select>
          ) : (

            <Input 
              type={type} 
              value={currentValue} 
              onChange={(e) => setFormData(setNestedValue(formData, fieldPath, e.target.value))}
            />
          )
        ) : (
          <p style={{ marginTop: "8px" }}>
            {type === "checkbox" ? (currentValue ? "Yes" : "No") : (currentValue || "-")}
          </p>
        )}
      </Col>
    );
  };

  return (
    <div style={{ padding: "24px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h3 style={{ fontSize: "20px", fontWeight: 600, margin: 0 }}>Company Details</h3>
        {!isEditing ? (
          <Button color="primary" onClick={() => setIsEditing(true)} style={{ backgroundColor: "#33A6CD", border: "none", borderRadius: "20px" }}>
            <FaEdit size={14} style={{ marginRight: "8px" }} /> Edit Company
          </Button>
        ) : (
          <Button color="success" onClick={handleSave} style={{ borderRadius: "20px" }}>
            <FaSave size={14} style={{ marginRight: "8px" }} /> Save Changes
          </Button>
        )}
      </div>

      <Card style={{ borderRadius: "16px", boxShadow: "0 2px 8px rgba(0,0,0,0.08)" }}>
        <CardBody>
          {isLoading && (
            <div style={{ textAlign: "center", padding: "40px", display: "flex", flexDirection: "column", alignItems: "center", gap: "16px" }}>
              <Spinner color="primary" />
              <p style={{ color: "#667085" }}>Loading company data...</p>
            </div>
          )}
          {!isLoading && (
          <>
          {/* Company Logo & Basic Info */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
            <div style={{ width: "120px", height: "120px", borderRadius: "50%", backgroundColor: "#33A6CD", display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "48px", fontWeight: "bold" }}>
              {(companyData?.name || "K").charAt(0)}
            </div>
            {isEditing && (
              <Button bsSize="sm" variant="outline" style={{ borderColor: "#33A6CD", color: "#33A6CD" }}>
                Upload Logo
              </Button>
            )}
          </div>

          {/* Basic Information */}
          <h5 style={{ marginBottom: "16px", color: "#33A6CD" }}>Basic Information</h5>
          <Row>
            {renderField("Company Name", companyData.name, "name")}
            {renderField("Company Size", companyData.size, "size", "number")}
            {renderField("Sector/Industry", companyData.sector, "sector", "select")}
            {renderField("Business Type", companyData.businessType, "businessType", "select")}
            {renderField("Years in Operation", companyData.yearsInOperation, "yearsInOperation", "number")}
            {renderField("Company Email", companyData.email, "email", "email")}
            {renderField("Phone Number", companyData.phone, "phone")}
            {renderField("Alternative Phone", companyData.alternativePhone, "alternativePhone")}
            {renderField("Fax Number", companyData.fax, "fax")}
            {renderField("Website", companyData.website, "website")}
            {renderField("Language", companyData.language, "language", "select")}
            {renderField("Timezone", companyData.timezone, "timezone", "select")}
            {renderField("Date Format", companyData.dateFormat, "dateFormat", "select")}
          </Row>

          <hr style={{ margin: "24px 0" }} />

          {/* Registration & Legal Information */}
          <h5 style={{ marginBottom: "16px", color: "#33A6CD" }}>Registration & Legal Information</h5>
          <Row>
            {renderField("Registration Number (CIPC)", companyData.registrationNumber, "registrationNumber")}
            {renderField("Tax ID / VAT Number", companyData.taxId, "taxId")}
            {renderField("VAT Number", companyData.vatNumber, "vatNumber")}
            {renderField("UIF Reference", companyData.uifReference, "uifReference")}
            {renderField("SDL Reference", companyData.sdlReference, "sdlReference")}
            {renderField("Work Injury Fund Ref", companyData.workInjuryFundRef, "workInjuryFundRef")}
            {renderField("Income Tax Number", companyData.incomeTaxNumber, "incomeTaxNumber")}
            {renderField("PAYE Reference", companyData.payeReference, "payeReference")}
            {renderField("SARS Branch", companyData.sarsBranch, "sarsBranch", "select")}
            {renderField("Provisional Taxpayer", companyData.provisionalTaxpayer, "provisionalTaxpayer", "checkbox")}
            {renderField("Tax Compliance Status", companyData.taxComplianceStatus, "taxComplianceStatus", "select")}
          </Row>

          <hr style={{ margin: "24px 0" }} />

          {/* Banking Information */}
          <h5 style={{ marginBottom: "16px", color: "#33A6CD" }}>Banking Information</h5>
          <Row>
            {renderField("Bank Name", companyData?.bank?.bankName || "", "bank.bankName", "select")}
            {renderField("Account Name", companyData?.bank?.accountName || "", "bank.accountName")}
            {renderField("Account Number", companyData?.bank?.accountNumber || "", "bank.accountNumber")}
            {renderField("Branch Code", companyData?.bank?.branchCode || "", "bank.branchCode")}
            {renderField("Account Type", companyData?.bank?.accountType || "", "bank.accountType", "select")}
            {renderField("SWIFT Code", companyData?.bank?.swiftCode || "", "bank.swiftCode")}
          </Row>

          <hr style={{ margin: "24px 0" }} />

          {/* Contact Persons */}
          <h5 style={{ marginBottom: "16px", color: "#33A6CD" }}>Key Contact Persons</h5>
          <h6 style={{ fontSize: "14px", marginBottom: "12px", color: "#4A5568" }}>CEO / Managing Director</h6>
          <Row>
            {renderField("CEO Name", companyData.contacts.ceo.name, "contacts.ceo.name")}
            {renderField("CEO Email", companyData.contacts.ceo.email, "contacts.ceo.email", "email")}
            {renderField("CEO Phone", companyData.contacts.ceo.phone, "contacts.ceo.phone")}
          </Row>
          <div style={{ marginTop: "12px" }} />
          <h6 style={{ fontSize: "14px", marginBottom: "12px", color: "#4A5568" }}>Finance Director / CFO</h6>
          <Row>
            {renderField("Finance Name", companyData.contacts.finance.name, "contacts.finance.name")}
            {renderField("Finance Email", companyData.contacts.finance.email, "contacts.finance.email", "email")}
            {renderField("Finance Phone", companyData.contacts.finance.phone, "contacts.finance.phone")}
          </Row>
          <div style={{ marginTop: "12px" }} />
          <h6 style={{ fontSize: "14px", marginBottom: "12px", color: "#4A5568" }}>Payroll Manager</h6>
          <Row>
            {renderField("Payroll Name", companyData.contacts.payroll.name, "contacts.payroll.name")}
            {renderField("Payroll Email", companyData.contacts.payroll.email, "contacts.payroll.email", "email")}
            {renderField("Payroll Phone", companyData.contacts.payroll.phone, "contacts.payroll.phone")}
          </Row>

          <hr style={{ margin: "24px 0" }} />

          {/* Address Information */}
          <h5 style={{ marginBottom: "16px", color: "#33A6CD" }}>Address Information</h5>
          <Row>
            {renderField("Physical Address", companyData.address.physicalAddress, "address.physicalAddress", "textarea")}
            {renderField("Postal Address", companyData.address.postalAddress, "address.postalAddress", "textarea")}
            {renderField("Street", companyData.address.street, "address.street")}
            {renderField("City", companyData.address.city, "address.city")}
            {renderField("Province", companyData.address.state, "address.state")}
            {renderField("Country", companyData.address.country, "address.country")}
            {renderField("Postal Code", companyData.address.postalCode, "address.postalCode")}
          </Row>

          <hr style={{ margin: "24px 0" }} />

          {/* Fiscal & Status Information */}
          <h5 style={{ marginBottom: "16px", color: "#33A6CD" }}>Fiscal Year & Status</h5>
          <Row>
            {renderField("Fiscal Year Start", companyData.fiscalYearStart, "fiscalYearStart", "date")}
            {renderField("Fiscal Year End", companyData.fiscalYearEnd, "fiscalYearEnd", "date")}
            {renderField("Company Status", companyData.status, "status", "select")}
            {renderField("Verification Status", companyData.verified, "verified", "checkbox")}
            {renderField("Last Audit Date", companyData.lastAuditDate, "lastAuditDate", "date")}
          </Row>
          </>
          )}
        </CardBody>
      </Card>
    </div>
  );
};

// ============================================
// TYPE DEFINITIONS & STRUCUTRED INTERFACES
// ============================================
interface Employee {
  id: string;
  employeeCode: string;
  name: string;
  department: string;
  position: string;
  basicSalary: number;
  allowances: {
    housing: number;
    transport: number;
    medical: number;
    other: number;
  };
  bankAccount: string;
  taxReference: string;
  uifReference: string;
  joinDate: string;
  status: "active" | "on_leave" | "terminated";
}

interface PayrollRun {
  id: string;
  period: string;
  periodStart: string;
  periodEnd: string;
  frequency: "Weekly" | "Bi-Weekly" | "Monthly";
  status: "draft" | "attendance_imported" | "calculated" | "approved" | "reports_generated" | "submitted";
  employeeCount: number;
  totalGross: number;
  totalDeductions: number;
  totalNetPay: number;
  approvedBy?: string;
  approvedAt?: string;
  submittedAt?: string;
  submissionReceipt?: string;
  createdAt: string;
  updatedAt: string;
}

interface PayrollCalculation {
  id: string;
  payrollRunId: string;
  employeeId: string;
  basicSalary: number;
  allowances: {
    housing: number;
    transport: number;
    medical: number;
    other: number;
    total: number;
  };
  overtime: {
    hours: number;
    rate: number;
    amount: number;
  };
  commissions: number;
  grossEarnings: number;
  deductions: {
    paye: number;
    uif: number;
    sdl: number;
    pension: number;
    medicalAid: number;
    other: number;
    total: number;
  };
  netPay: number;
  employerCosts: {
    uif: number;
    sdl: number;
    skillsLevy: number;
    total: number;
  };
}

// ============================================
// STABLE SYSTEM MOCK DATA
// ============================================
const mockEmployees: Employee[] = [
  {
    id: "EMP001",
    employeeCode: "KHC001",
    name: "John Doe",
    department: "Engineering",
    position: "Senior Developer",
    basicSalary: 35000,
    allowances: { housing: 5000, transport: 2000, medical: 1500, other: 0 },
    bankAccount: "1234567890",
    taxReference: "1234567890",
    uifReference: "UIF001",
    joinDate: "2023-01-15",
    status: "active"
  },
  {
    id: "EMP002",
    employeeCode: "KHC002",
    name: "Jane Smith",
    department: "Sales",
    position: "Sales Manager",
    basicSalary: 45000,
    allowances: { housing: 7000, transport: 3000, medical: 2000, other: 1000 },
    bankAccount: "0987654321",
    taxReference: "0987654321",
    uifReference: "UIF002",
    joinDate: "2022-06-01",
    status: "active"
  },
  {
    id: "EMP003",
    employeeCode: "KHC003",
    name: "Pieter van der Merwe",
    department: "Operations",
    position: "Operations Manager",
    basicSalary: 40000,
    allowances: { housing: 6000, transport: 2500, medical: 1800, other: 500 },
    bankAccount: "1122334455",
    taxReference: "1122334455",
    uifReference: "UIF003",
    joinDate: "2023-03-10",
    status: "active"
  },
  {
    id: "EMP004",
    employeeCode: "KHC004",
    name: "Sarah Williams",
    department: "HR",
    position: "HR Specialist",
    basicSalary: 30000,
    allowances: { housing: 4000, transport: 1500, medical: 1200, other: 0 },
    bankAccount: "5566778899",
    taxReference: "5566778899",
    uifReference: "UIF004",
    joinDate: "2023-08-20",
    status: "active"
  }
];

// ============================================
// MAIN TAB COMPONENT
// ============================================
export const PayrollSettingsTab = () => {
  // ========== SETTINGS STATE ==========
  const [payrollSettings, setPayrollSettings] = useState({
    frequency: "Monthly",
    payDay: "25",
    currency: "ZAR",
    taxYear: "2026",
    overtimeRate: "1.5",
    weekendRate: "2.0",
    holidayRate: "2.5",
    uifEnabled: true,
    uifRate: "1.0",
    sdlEnabled: true,
    sdlRate: "1.0",
    payeEnabled: true,
    autoGeneratePayslips: true,
    allowSelfServicePayslips: true
  });

  const [isEditingSettings, setIsEditingSettings] = useState(false);
  const [settingsFormData, setSettingsFormData] = useState(payrollSettings);

  // ========== PROCESSING SYSTEM STATE ==========
  const [payrollRuns, setPayrollRuns] = useState<PayrollRun[]>([
    {
      id: "PR-2026-05",
      period: "May 2026",
      periodStart: "2026-05-01",
      periodEnd: "2026-05-31",
      frequency: "Monthly",
      status: "draft",
      employeeCount: mockEmployees.length,
      totalGross: 0,
      totalDeductions: 0,
      totalNetPay: 0,
      createdAt: "2026-05-01T08:00:00Z",
      updatedAt: "2026-05-01T08:00:00Z"
    }
  ]);
  
  const [activePayrollRun, setActivePayrollRun] = useState<PayrollRun | null>(null);
  const [payrollCalculations, setPayrollCalculations] = useState<PayrollCalculation[]>([]);
  const [reportGenerating, setReportGenerating] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  
  // Modals Toggles
  const [showExceptionsModal, setShowExceptionsModal] = useState(false);
  const [exceptionsList, setExceptionsList] = useState<string[]>([]);
  const [showPayrollRunModal, setShowPayrollRunModal] = useState(false);
  
  // Form Variables for New Payroll Period
  const [newRunPeriod, setNewRunPeriod] = useState("");
  const [newRunFrequency, setNewRunFrequency] = useState<"Weekly" | "Bi-Weekly" | "Monthly">("Monthly");

  // Inline CSS Object styles clean alignment configurations
  const styleTh: React.CSSProperties = {
    padding: "12px 10px",
    fontSize: "12px",
    fontWeight: 600,
    color: "#4A5568",
    backgroundColor: "#F7FAFC",
    borderBottom: "2px solid #E2E8F0 text-left"
  };

  const styleTd: React.CSSProperties = {
    padding: "12px 10px",
    fontSize: "13px",
    color: "#2D3748",
    borderBottom: "1px solid #EDF2F7",
    verticalAlign: "middle"
  };

  // ========== RUN ACTIONS & HANDLERS ==========
  const handleSaveSettings = () => {
    setPayrollSettings(settingsFormData);
    setIsEditingSettings(false);
  };

  const handleCancelSettings = () => {
    setSettingsFormData(payrollSettings);
    setIsEditingSettings(false);
  };

  const startNewPayrollRun = () => {
    if (!newRunPeriod.trim()) {
      return;
    }
    
    const newRun: PayrollRun = {
      id: `PR-${Date.now()}`,
      period: newRunPeriod,
      periodStart: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10),
      periodEnd: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString().slice(0, 10),
      frequency: newRunFrequency,
      status: "draft",
      employeeCount: mockEmployees.length,
      totalGross: 0,
      totalDeductions: 0,
      totalNetPay: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setPayrollRuns([newRun, ...payrollRuns]);
    setActivePayrollRun(newRun);
    setPayrollCalculations([]); 
    setShowPayrollRunModal(false);
    setNewRunPeriod("");
  };

  const importAttendanceData = () => {
    if (!activePayrollRun) return;
    setActivePayrollRun({ 
      ...activePayrollRun, 
      status: "attendance_imported",
      updatedAt: new Date().toISOString()
    });
  };

  const calculatePayroll = () => {
    if (!activePayrollRun) return;
    
    // Updated accurate statutory calculation structures
    const calculatePAYE = (annualTaxable: number): number => {
      let annualTax = 0;
      if (annualTaxable <= 237100) annualTax = annualTaxable * 0.18;
      else if (annualTaxable <= 370500) annualTax = 42678 + (annualTaxable - 237100) * 0.26;
      else if (annualTaxable <= 512800) annualTax = 77362 + (annualTaxable - 370500) * 0.31;
      else if (annualTaxable <= 673000) annualTax = 121475 + (annualTaxable - 512800) * 0.36;
      else if (annualTaxable <= 857900) annualTax = 179147 + (annualTaxable - 673000) * 0.39;
      else if (annualTaxable <= 1817000) annualTax = 251258 + (annualTaxable - 857900) * 0.41;
      else annualTax = 644389 + (annualTaxable - 1817000) * 0.45;

      const primaryRebate = 17235; 
      const taxAfterRebate = Math.max(0, annualTax - primaryRebate);
      return taxAfterRebate;
    };

    const overtimeMultiplier = parseFloat(payrollSettings.overtimeRate);
    
    const calculations: PayrollCalculation[] = mockEmployees.map(emp => {
      const totalAllowances = emp.allowances.housing + emp.allowances.transport + emp.allowances.medical + emp.allowances.other;
      const overtimeHours = emp.department === "Engineering" ? 8 : 0; 
      const overtimeAmount = overtimeHours * (emp.basicSalary / 160) * overtimeMultiplier;
      const commissions = emp.department === "Sales" ? emp.basicSalary * 0.05 : 0;
      const grossEarnings = emp.basicSalary + totalAllowances + overtimeAmount + commissions;
      
      const annualTaxable = grossEarnings * 12;
      const annualPAYE = calculatePAYE(annualTaxable);
      const paye = payrollSettings.payeEnabled ? Math.round(annualPAYE / 12) : 0;
      
      // Limit statutory ceiling values safely 
      const uifEmployee = payrollSettings.uifEnabled ? Math.min(grossEarnings * (parseFloat(payrollSettings.uifRate) / 100), 177.12) : 0;
      const sdl = payrollSettings.sdlEnabled ? grossEarnings * (parseFloat(payrollSettings.sdlRate) / 100) : 0;
      
      const totalDeductions = paye + uifEmployee;
      const netPay = grossEarnings - totalDeductions;
      
      return {
        id: `CALC-${activePayrollRun.id}-${emp.id}`,
        payrollRunId: activePayrollRun.id,
        employeeId: emp.id,
        basicSalary: emp.basicSalary,
        allowances: {
          housing: emp.allowances.housing,
          transport: emp.allowances.transport,
          medical: emp.allowances.medical,
          other: emp.allowances.other,
          total: totalAllowances
        },
        overtime: {
          hours: overtimeHours,
          rate: overtimeMultiplier,
          amount: overtimeAmount
        },
        commissions: commissions,
        grossEarnings: grossEarnings,
        deductions: {
          paye: paye,
          uif: uifEmployee,
          sdl: sdl,
          pension: 0,
          medicalAid: 0,
          other: 0,
          total: totalDeductions
        },
        netPay: netPay,
        employerCosts: {
          uif: uifEmployee,
          sdl: sdl,
          skillsLevy: grossEarnings * 0.01,
          total: uifEmployee + sdl + (grossEarnings * 0.01)
        }
      };
    });
    
    setPayrollCalculations(calculations);
    
    const totalGross = calculations.reduce((sum, calc) => sum + calc.grossEarnings, 0);
    const totalDeductions = calculations.reduce((sum, calc) => sum + calc.deductions.total, 0);
    const totalNetPay = calculations.reduce((sum, calc) => sum + calc.netPay, 0);
    
    const updatedRun: PayrollRun = { 
      ...activePayrollRun, 
      status: "calculated",
      totalGross: totalGross,
      totalDeductions: totalDeductions,
      totalNetPay: totalNetPay,
      updatedAt: new Date().toISOString()
    };

    setActivePayrollRun(updatedRun);
    setPayrollRuns(payrollRuns.map(r => r.id === activePayrollRun.id ? updatedRun : r));
  };

  const detectExceptions = (calculation: PayrollCalculation, employee: Employee): string[] => {
    const exceptions: string[] = [];
    if (calculation.overtime.amount > calculation.basicSalary * 0.3) {
      exceptions.push(`High Overtime volume flags warning thresholds (exceeds 30% of base salary rate)`);
    }
    if (calculation.netPay < 0) {
      exceptions.push("Critical Error: Calculated runtime evaluated a negative net income value.");
    }
    return exceptions;
  };

  const approvePayrollRun = () => {
    if (!activePayrollRun) return;
    
    const allExceptions: string[] = [];
    payrollCalculations.forEach(calc => {
      const employee = mockEmployees.find(emp => emp.id === calc.employeeId);
      if (employee) {
        const ex = detectExceptions(calc, employee);
        if (ex.length) {
          allExceptions.push(`${employee.name}: ${ex.join(", ")}`);
        }
      }
    });
    
    if (allExceptions.length > 0) {
      setExceptionsList(allExceptions);
      setShowExceptionsModal(true);
      return;
    }
    
    const updatedRun: PayrollRun = { 
      ...activePayrollRun, 
      status: "approved", 
      approvedBy: "System Administrator", 
      approvedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setActivePayrollRun(updatedRun);
    setPayrollRuns(payrollRuns.map(r => r.id === activePayrollRun.id ? updatedRun : r));
  };

  const generateStatReports = () => {
    if (!activePayrollRun) return;
    setReportGenerating(true);
    
    setTimeout(() => {
      const totalPAYE = payrollCalculations.reduce((sum, calc) => sum + calc.deductions.paye, 0);
      const totalUIF = payrollCalculations.reduce((sum, calc) => sum + calc.deductions.uif, 0);
      const totalSDL = payrollCalculations.reduce((sum, calc) => sum + calc.deductions.sdl, 0);
      
      const emp201Report = {
        declarationType: "EMP201",
        referencePeriod: activePayrollRun.period,
        taxYear: payrollSettings.taxYear,
        generationTimestamp: new Date().toISOString(),
        financials: {
          payeAmount: totalPAYE,
          uifAmount: totalUIF * 2, // Combined Employee + Employer contributions
          sdlAmount: totalSDL,
          totalPayable: totalPAYE + (totalUIF * 2) + totalSDL
        },
        employeeCount: activePayrollRun.employeeCount,
      };
      
      const blob = new Blob([JSON.stringify(emp201Report, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `EMP201_${activePayrollRun.period.replace(/ /g, "_")}.json`;
      a.click();
      URL.revokeObjectURL(url);
      
      const updatedRun: PayrollRun = { 
        ...activePayrollRun, 
        status: "reports_generated",
        updatedAt: new Date().toISOString()
      };

      setActivePayrollRun(updatedRun);
      setPayrollRuns(payrollRuns.map(r => r.id === activePayrollRun.id ? updatedRun : r));
      setReportGenerating(false);
    }, 1200);
  };

  const submitToSARS = () => {
    if (!activePayrollRun) return;
    setSubmitting(true);
    
    setTimeout(() => {
      const receipt = `SARS-REC-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const updatedRun: PayrollRun = { 
        ...activePayrollRun, 
        status: "submitted", 
        submittedAt: new Date().toISOString(),
        submissionReceipt: receipt,
        updatedAt: new Date().toISOString()
      };

      setActivePayrollRun(updatedRun);
      setPayrollRuns(payrollRuns.map(r => r.id === activePayrollRun.id ? updatedRun : r));
      setSubmitting(false);
    }, 1500);
  };

  const renderStatusBadge = (status: PayrollRun["status"]) => {
    const config: Record<PayrollRun["status"], { color: string; text: string }> = {
      draft: { color: "secondary", text: "Draft Plan" },
      attendance_imported: { color: "info", text: "Data Imported" },
      calculated: { color: "warning", text: "Calculated" },
      approved: { color: "success", text: "Approved Run" },
      reports_generated: { color: "primary", text: "EMP201 Generated" },
      submitted: { color: "success", text: "SARS Submitted" },
    };
    const current = config[status] || config.draft;
    return <Badge color={current.color} pill className="px-3 py-1">{current.text}</Badge>;
  };

  return (
    <div className="container-fluid px-0">
      
      {/* ============================================
          SECTION 1: SYSTEM PARAMETERS & CONFIGURATION
          ============================================ */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 className="fw-bold mb-1 text-dark">Payroll Control Panel</h4>
          <p className="text-muted small mb-0">Configure localized tax rule structures and processing timelines</p>
        </div>
        {!isEditingSettings ? (
          <Button color="info" className="text-white px-4 pill-btn" onClick={() => setIsEditingSettings(true)}>
            <FaEdit className="me-2" /> Edit Configuration
          </Button>
        ) : (
          <div className="d-flex gap-2">
            <Button color="secondary" outline onClick={handleCancelSettings}>Cancel</Button>
            <Button color="success" className="px-4" onClick={handleSaveSettings}>
              <FaSave className="me-2" /> Commit Rules
            </Button>
          </div>
        )}
      </div>

      <Card className="border-0 shadow-sm rounded-4 mb-4">
        <CardBody className="p-4">
          <h5 className="fw-bold text-info mb-3 d-flex align-items-center">
            <FaBuilding className="me-2" /> Operational Parameters
          </h5>
          <Row className="g-3">
            <Col md={3}>
              <FormGroup>
                <Label className="small text-muted fw-bold">Processing Cycle Frequency</Label>
                {isEditingSettings ? (
                  <Input type="select" value={settingsFormData.frequency} onChange={(e) => setSettingsFormData({ ...settingsFormData, frequency: e.target.value })}>
                    <option>Weekly</option>
                    <option>Bi-Weekly</option>
                    <option>Monthly</option>
                  </Input>
                ) : (
                  <p className="h6 fw-normal mt-1">{payrollSettings.frequency}</p>
                )}
              </FormGroup>
            </Col>
            <Col md={3}>
              <FormGroup>
                <Label className="small text-muted fw-bold">Scheduled Pay Day</Label>
                {isEditingSettings ? (
                  <Input type="select" value={settingsFormData.payDay} onChange={(e) => setSettingsFormData({ ...settingsFormData, payDay: e.target.value })}>
                    {[...Array(31)].map((_, i) => <option key={i+1}>{i+1}</option>)}
                  </Input>
                ) : (
                  <p className="h6 fw-normal mt-1">Day {payrollSettings.payDay} of calendar month</p>
                )}
              </FormGroup>
            </Col>
            <Col md={3}>
              <FormGroup>
                <Label className="small text-muted fw-bold">Base Currency Code</Label>
                {isEditingSettings ? (
                  <Input type="select" value={settingsFormData.currency} onChange={(e) => setSettingsFormData({ ...settingsFormData, currency: e.target.value })}>
                    <option>ZAR - South African Rand</option>
                    <option>USD - US Dollar</option>
                  </Input>
                ) : (
                  <p className="h6 fw-normal mt-1">{payrollSettings.currency}</p>
                )}
              </FormGroup>
            </Col>
            <Col md={3}>
              <FormGroup>
                <Label className="small text-muted fw-bold">Active SARS Tax Year</Label>
                {isEditingSettings ? (
                  <Input type="select" value={settingsFormData.taxYear} onChange={(e) => setSettingsFormData({ ...settingsFormData, taxYear: e.target.value })}>
                    <option>2025</option>
                    <option>2026</option>
                  </Input>
                ) : (
                  <p className="h6 fw-normal mt-1">{payrollSettings.taxYear}</p>
                )}
              </FormGroup>
            </Col>
          </Row>

          <hr className="my-4 text-light" />

          <h5 className="fw-bold text-info mb-3">Statutory & Core Contribution Framework</h5>
          <Row className="g-3">
            <Col md={4}>
              <FormGroup>
                <Label className="small text-muted fw-bold">UIF Contribution Rate</Label>
                {isEditingSettings ? (
                  <div className="pt-1">
                    <FormGroup check inline>
                      <Input type="checkbox" checked={settingsFormData.uifEnabled} onChange={(e) => setSettingsFormData({ ...settingsFormData, uifEnabled: e.target.checked })} />
                      <Label check className="small ms-1">Active</Label>
                    </FormGroup>
                    <Input type="number" step="0.1" className="mt-2" value={settingsFormData.uifRate} onChange={(e) => setSettingsFormData({ ...settingsFormData, uifRate: e.target.value })} disabled={!settingsFormData.uifEnabled} />
                  </div>
                ) : (
                  <p className="h6 fw-normal mt-1">{payrollSettings.uifEnabled ? `Enabled (${payrollSettings.uifRate}%)` : "Suspended"}</p>
                )}
              </FormGroup>
            </Col>
            <Col md={4}>
              <FormGroup>
                <Label className="small text-muted fw-bold">SDL Levy Accumulation</Label>
                {isEditingSettings ? (
                  <div className="pt-1">
                    <FormGroup check inline>
                      <Input type="checkbox" checked={settingsFormData.sdlEnabled} onChange={(e) => setSettingsFormData({ ...settingsFormData, sdlEnabled: e.target.checked })} />
                      <Label check className="small ms-1">Active</Label>
                    </FormGroup>
                    <Input type="number" step="0.1" className="mt-2" value={settingsFormData.sdlRate} onChange={(e) => setSettingsFormData({ ...settingsFormData, sdlRate: e.target.value })} disabled={!settingsFormData.sdlEnabled} />
                  </div>
                ) : (
                  <p className="h6 fw-normal mt-1">{payrollSettings.sdlEnabled ? `Enabled (${payrollSettings.sdlRate}%)` : "Suspended"}</p>
                )}
              </FormGroup>
            </Col>
            <Col md={4}>
              <FormGroup>
                <Label className="small text-muted fw-bold">PAYE Automatic Deduction Calculation</Label>
                {isEditingSettings ? (
                  <div className="pt-2">
                    <FormGroup check>
                      <Input type="checkbox" checked={settingsFormData.payeEnabled} onChange={(e) => setSettingsFormData({ ...settingsFormData, payeEnabled: e.target.checked })} />
                      <Label check className="small ms-1">Enforce Pay-As-You-Earn Multipliers</Label>
                    </FormGroup>
                  </div>
                ) : (
                  <p className="h6 fw-normal mt-1">{payrollSettings.payeEnabled ? "Enforced Bracket Calculations" : "Bypassed / Off"}</p>
                )}
              </FormGroup>
            </Col>
          </Row>
        </CardBody>
      </Card>

      {/* ============================================
          SECTION 2: PROCESSING RUNS WORKFLOW
          ============================================ */}
      <div className="d-flex justify-content-between align-items-center mb-4 mt-5">
        <div>
          <h4 className="fw-bold mb-1 text-dark">Execution Registry & Processing Periods</h4>
          <p className="text-muted small mb-0">Track execution history logs or launch active settlement pipelines</p>
        </div>
        <Button color="info" className="text-white px-4" onClick={() => setShowPayrollRunModal(true)}>
          <FaPlus className="me-2" /> Open Settlement Window
        </Button>
      </div>

      <Card className="border-0 shadow-sm rounded-4 mb-4">
        <CardBody className="p-4">
          <Table responsive hover className="align-middle mb-0">
            <thead>
              <tr>
                <th style={styleTh}>Target Period</th>
                <th style={styleTh}>Frequency</th>
                <th style={styleTh}>Start Scope</th>
                <th style={styleTh}>End Scope</th>
                <th style={styleTh}>State</th>
                <th style={styleTh} className="text-center">Headcount</th>
                <th style={styleTh} className="text-end">Gross Aggregate</th>
                <th style={styleTh} className="text-center">Action Interface</th>
              </tr>
            </thead>
            <tbody>
              {payrollRuns.map((run) => (
                <tr key={run.id} className={activePayrollRun?.id === run.id ? "table-light fw-medium" : ""}>
                  <td style={styleTd}><strong>{run.period}</strong></td>
                  <td style={styleTd}>{run.frequency}</td>
                  <td style={styleTd}>{run.periodStart}</td>
                  <td style={styleTd}>{run.periodEnd}</td>
                  <td style={styleTd}>{renderStatusBadge(run.status)}</td>
                  <td style={styleTd} className="text-center">{run.employeeCount}</td>
                  <td style={styleTd} className="text-end">{run.totalGross > 0 ? `R ${run.totalGross.toLocaleString()}` : "—"}</td>
                  <td style={styleTd} className="text-center">
                    <Button size="sm" color={activePayrollRun?.id === run.id ? "info" : "outline-info"} className={activePayrollRun?.id === run.id ? "text-white px-3" : "px-3"} onClick={() => setActivePayrollRun(run)}>
                      {activePayrollRun?.id === run.id ? "Viewing Active" : "Select Context"}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </CardBody>
      </Card>

      {/* Active Pipeline Workflow Panel */}
      {activePayrollRun && (
        <Card className="border-2 border-info shadow-sm rounded-4 mb-5">
          <CardBody className="p-4">
            <div className="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom text-wrap gap-2">
              <div>
                <span className="text-info text-uppercase tracking-wider small d-block fw-bold mb-1">Active Pipeline Step Environment</span>
                <h4 className="fw-bold text-dark mb-0">{activePayrollRun.period} Workflow Engine Instance</h4>
              </div>
              <div>{renderStatusBadge(activePayrollRun.status)}</div>
            </div>

            {/* Stage Action Step Controls */}
            <Row className="g-2 text-center mb-4">
              <Col>
                <Button color="primary" block disabled={activePayrollRun.status !== "draft"} onClick={importAttendanceData} className="py-2 d-flex align-items-center justify-content-center gap-2">
                  <FaCloudUploadAlt /> 1. Import Timecards
                </Button>
              </Col>
              <Col>
                <Button color="primary" block disabled={activePayrollRun.status !== "attendance_imported"} onClick={calculatePayroll} className="py-2 d-flex align-items-center justify-content-center gap-2">
                  <FaCalculator /> 2. Process Math Calculations
                </Button>
              </Col>
              <Col>
                <Button color="primary" block disabled={activePayrollRun.status !== "calculated"} onClick={approvePayrollRun} className="py-2 d-flex align-items-center justify-content-center gap-2">
                  <FaCheckCircle /> 3. Freeze & Approve
                </Button>
              </Col>
              <Col>
                <Button color="primary" block disabled={activePayrollRun.status !== "approved"} onClick={generateStatReports} className="py-2 d-flex align-items-center justify-content-center gap-2">
                  {reportGenerating ? "Compiling..." : "4. Compile EMP201 Form"}
                </Button>
              </Col>
              <Col>
                <Button color="success" block disabled={activePayrollRun.status !== "reports_generated"} onClick={submitToSARS} className="py-2 d-flex align-items-center justify-content-center gap-2">
                  {submitting ? "Transmitting..." : "5. Dispatch to SARS eFiling"}
                </Button>
              </Col>
            </Row>

            {/* Context Execution Alerts Summary */}
            {activePayrollRun.status !== "draft" && (
              <Alert color="light" className="border rounded-3 p-3 mb-4">
                <Row className="text-center text-dark">
                  <Col md={3} className="border-end">
                    <span className="small text-muted d-block mb-1">Gross Base Pay</span>
                    <strong className="h5 fw-bold text-dark">R {activePayrollRun.totalGross.toLocaleString()}</strong>
                  </Col>
                  <Col md={3} className="border-end">
                    <span className="small text-muted d-block mb-1">Aggregate Revenue Reductions</span>
                    <strong className="h5 fw-bold text-danger">R {activePayrollRun.totalDeductions.toLocaleString()}</strong>
                  </Col>
                  <Col md={3} className="border-end">
                    <span className="small text-muted d-block mb-1">Disbursed Liquid Remittance</span>
                    <strong className="h5 fw-bold text-success">R {activePayrollRun.totalNetPay.toLocaleString()}</strong>
                  </Col>
                  <Col md={3}>
                    <span className="small text-muted d-block mb-1">Calculated Headcount File</span>
                    <strong className="h5 fw-bold text-dark">{activePayrollRun.employeeCount} Profiles</strong>
                  </Col>
                </Row>
              </Alert>
            )}

            {/* Nested Individual Line Item Ledger Table */}
            {payrollCalculations.length > 0 && (
              <div className="mt-4">
                <h6 className="fw-bold mb-3 text-dark">Calculated Line-Item Ledger Outputs</h6>
                <div className="table-responsive rounded-3 border" style={{ maxHeight: "350px", overflowY: "auto" }}>
                  <Table hover striped size="sm" className="align-middle mb-0 bg-white">
                    <thead className="bg-light sticky-top" style={{ zIndex: 1 }}>
                      <tr>
                        <th style={styleTh}>Personnel Target</th>
                        <th style={styleTh} className="text-end">Base Rate</th>
                        <th style={styleTh} className="text-end">Allowances</th>
                        <th style={styleTh} className="text-end">Overtime Premium</th>
                        <th style={styleTh} className="text-end">Gross Output</th>
                        <th style={styleTh} className="text-end">SARS PAYE</th>
                        <th style={styleTh} className="text-end">UIF Premium</th>
                        <th style={styleTh} className="text-end text-success">Net Allocation</th>
                      </tr>
                    </thead>
                    <tbody>
                      {payrollCalculations.map((calc) => {
                        const employee = mockEmployees.find(e => e.id === calc.employeeId);
                        const rowExceptions = employee ? detectExceptions(calc, employee) : [];
                        return (
                          <tr key={calc.id} className={rowExceptions.length > 0 ? "table-warning text-dark" : ""}>
                            <td style={styleTd}>
                              <div>
                                <span className="d-block fw-bold">{employee?.name || calc.employeeId}</span>
                                <span className="text-muted small fs-7">{employee?.position}</span>
                              </div>
                            </td>
                            <td style={styleTd} className="text-end">R {calc.basicSalary.toLocaleString()}</td>
                            <td style={styleTd} className="text-end">R {calc.allowances.total.toLocaleString()}</td>
                            <td style={styleTd} className="text-end">R {calc.overtime.amount.toLocaleString()}</td>
                            <td style={styleTd} className="text-end fw-bold">R {calc.grossEarnings.toLocaleString()}</td>
                            <td style={styleTd} className="text-end">R {calc.deductions.paye.toLocaleString()}</td>
                            <td style={styleTd} className="text-end">R {calc.deductions.uif.toLocaleString()}</td>
                            <td style={styleTd} className="text-end fw-bold text-success">R {calc.netPay.toLocaleString()}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </Table>
                </div>
              </div>
            )}
          </CardBody>
        </Card>
      )}

      {/* ============================================
          SYSTEM MODALS (REACTSTRAP STANDARD POPUPS)
          ============================================ */}
      
      {/* Modal 1: Launch Period Modal */}
      <Modal isOpen={showPayrollRunModal} toggle={() => setShowPayrollRunModal(!showPayrollRunModal)} centered>
        <ModalHeader toggle={() => setShowPayrollRunModal(!showPayrollRunModal)} className="fw-bold">Open Active Settlement Window</ModalHeader>
        <ModalBody>
          <FormGroup>
            <Label className="small fw-bold text-muted">Period Label Identification Code</Label>
            <Input type="text" placeholder="e.g., June 2026" value={newRunPeriod} onChange={(e) => setNewRunPeriod(e.target.value)} />
          </FormGroup>
          <FormGroup className="mt-3">
            <Label className="small fw-bold text-muted">Execution Model Frequency Override</Label>
            <Input type="select" value={newRunFrequency} onChange={(e) => setNewRunFrequency(e.target.value as any)}>
              <option value="Monthly">Monthly Cycle Strategy</option>
              <option value="Bi-Weekly">Bi-Weekly Alternate Strategy</option>
              <option value="Weekly">Weekly Intermittent Strategy</option>
            </Input>
          </FormGroup>
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" outline onClick={() => setShowPayrollRunModal(false)}>Close Interface</Button>
          <Button color="info" className="text-white" disabled={!newRunPeriod.trim()} onClick={startNewPayrollRun}>Initialize Context Window</Button>
        </ModalFooter>
      </Modal>

      {/* Modal 2: Process Block Exception Warning Modal */}
      <Modal isOpen={showExceptionsModal} toggle={() => setShowExceptionsModal(!showExceptionsModal)} centered>
        <ModalHeader className="bg-warning text-dark fw-bold">
          <FaExclamationTriangle className="me-2" /> Validation Flags Detected
        </ModalHeader>
        <ModalBody>
          <p className="small text-muted mb-3">The structural parser intercepted execution calculations breaking soft bounds configuration. Rectify discrepancies before signing configuration files:</p>
          <ul className="text-danger small fw-medium ps-3">
            {exceptionsList.map((err, idx) => <li key={idx} className="mb-1">{err}</li>)}
          </ul>
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" size="sm" onClick={() => setShowExceptionsModal(false)}>Acknowledge Operational Audit</Button>
        </ModalFooter>
      </Modal>

    </div>
  );
};

// ============================================
// STYLES & INTERFACES (MATCHING SCREENSHOT CORES)
// ============================================
const thStyle: React.CSSProperties = {
  padding: "10px 8px",
  textAlign: "left",
  fontSize: "12px",
  fontWeight: 600,
  color: "#4A5568",
  borderBottom: "1px solid #CBD5E0",
  backgroundColor: "#EDF2F7"
};

const tdStyle: React.CSSProperties = {
  padding: "10px 8px",
  fontSize: "12px",
  color: "#2D3748",
  borderBottom: "1px solid #EDF2F7",
  verticalAlign: "middle",
};

interface LeaveRowRule {
  id: string;
  description: string;
  entitlementPerCycle: string;
  cycleStartDate: string;
  nextCycleStartDate: string;
  openingBalance: string;
  accrualThisPeriod: string;
  takenThisPeriod: string;
  closingBalance: string;
  plannedLeave: string;
  isEntitlementEditable: boolean;
  isCycleDateEditable: boolean;
}

interface LeaveCategory {
  id: string;
  categoryName: string; 
  rules: LeaveRowRule[];
}

interface EmployeeLeaveProfile {
  leaveStartDate: string;
  leaveBasis: "Working Days" | "Calendar Days";
  workDays: { [key: string]: boolean };
  categories: LeaveCategory[];
}

// ============================================
// COMPONENT: LEAVE CATEGORY SECTION
// ============================================
const LeaveCategorySection = ({ 
  category, 
  onUpdateRow 
}: { 
  category: LeaveCategory; 
  onUpdateRow: (categoryId: string, rowId: string, updatedFields: Partial<LeaveRowRule>) => void 
}) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div style={{ marginBottom: "16px", border: "1px solid #E2E8F0", borderRadius: "8px", overflow: "hidden", backgroundColor: "white" }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 16px",
          backgroundColor: "#F7FAFC",
          cursor: "pointer",
          borderBottom: isExpanded ? "1px solid #E2E8F0" : "none",
        }}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          {isExpanded ? <FaChevronDown size={14} /> : <FaChevronRight size={14} />}
          <span style={{ fontWeight: 600, fontSize: "14px" }}>{category.categoryName}</span>
        </div>
      </div>

      {isExpanded && (
        <div style={{ padding: "16px", backgroundColor: "white", overflowX: "auto" }}>
          <table style={{ width: "100%", fontSize: "13px", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ backgroundColor: "#EDF2F7" }}>
                <th style={thStyle}>Leave rule description</th>
                <th style={thStyle}>Entitlement per cycle</th>
                <th style={thStyle}>Cycle start date</th>
                <th style={thStyle}>Next cycle start date</th>
                <th style={thStyle}>Opening balance</th>
                <th style={thStyle}>Accrual this period</th>
                <th style={thStyle}>Taken this period</th>
                <th style={thStyle}>Closing balance</th>
                <th style={thStyle}>Planned leave</th>
              </tr>
            </thead>
            <tbody>
              {category.rules.map((row) => {
                const isGreenRow = row.description.toLowerCase().includes("remaining") || 
                                   row.description.toLowerCase().includes("3 year cycle") || 
                                   row.description === category.categoryName;
                const rowBg = isGreenRow ? "#E6F4EA" : "#FFFFFF";

                return (
                  <tr key={row.id} style={{ backgroundColor: rowBg }}>
                    <td style={tdStyle}>{row.description}</td>
                    
                    <td style={tdStyle}>
                      {row.isEntitlementEditable ? (
                        <Input 
                          type="text" 
                          value={row.entitlementPerCycle} 
                          onChange={(e) => onUpdateRow(category.id, row.id, { entitlementPerCycle: e.target.value })} 
                          bsSize="sm"
                          style={{ width: "100px" }}
                        />
                      ) : row.entitlementPerCycle || ""}
                    </td>

                    <td style={tdStyle}>
                      {row.isCycleDateEditable ? (
                        <Input 
                          type="text" 
                          value={row.cycleStartDate} 
                          onChange={(e) => onUpdateRow(category.id, row.id, { cycleStartDate: e.target.value })} 
                          bsSize="sm"
                          style={{ width: "110px" }}
                        />
                      ) : row.cycleStartDate || ""}
                    </td>

                    <td style={tdStyle}>{row.nextCycleStartDate || ""}</td>
                    
                    <td style={tdStyle}>
                      <Input 
                        type="text" 
                        value={row.openingBalance} 
                        onChange={(e) => onUpdateRow(category.id, row.id, { openingBalance: e.target.value })} 
                        bsSize="sm"
                        style={{ width: "110px" }}
                      />
                    </td>

                    <td style={tdStyle}>{row.accrualThisPeriod}</td>
                    <td style={tdStyle}>{row.takenThisPeriod}</td>
                    <td style={tdStyle}>{row.closingBalance}</td>
                    <td style={tdStyle}>{row.plannedLeave}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ============================================
// MAIN COMPONENT: LEAVE SETTINGS TAB
// ============================================
const LeaveSettingsTab = () => {
  const [profile, setProfile] = useState<EmployeeLeaveProfile>({
    leaveStartDate: "January 2013",
    leaveBasis: "Working Days",
    workDays: { Monday: true, Tuesday: true, Wednesday: true, Thursday: true, Friday: true, Saturday: false, Sunday: false },
    categories: [
      {
        id: "cat_annual",
        categoryName: "Annual Leave",
        rules: [
          { id: "ann_1", description: "Annual Leave", entitlementPerCycle: "15.0000", cycleStartDate: "2025-01-01", nextCycleStartDate: "2026-01-01", openingBalance: "2.5000", accrualThisPeriod: "1.2500", takenThisPeriod: "0.0000", closingBalance: "3.7500", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: false },
          { id: "ann_2", description: "Annual Leave 6 months remaining", entitlementPerCycle: "", cycleStartDate: "2025-01-01", nextCycleStartDate: "2026-01-01", openingBalance: "15.0000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "15.0000", plannedLeave: "0.0000", isEntitlementEditable: false, isCycleDateEditable: false },
          { id: "ann_3", description: "Annual Leave excess", entitlementPerCycle: "", cycleStartDate: "", nextCycleStartDate: "", openingBalance: "148.5000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "148.5000", plannedLeave: "0.0000", isEntitlementEditable: false, isCycleDateEditable: false }
        ]
      },
      {
        id: "cat_sick",
        categoryName: "Sick Leave",
        rules: [
          { id: "sick_1", description: "Sick Leave first 6 months", entitlementPerCycle: "6.0000", cycleStartDate: "2013-01-01", nextCycleStartDate: "", openingBalance: "0.0000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "0.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true },
          { id: "sick_2", description: "Sick Leave remaining 30 months", entitlementPerCycle: "24.0000", cycleStartDate: "2013-07-01", nextCycleStartDate: "", openingBalance: "0.0000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "0.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true },
          { id: "sick_3", description: "Sick Leave 3 year cycle", entitlementPerCycle: "30.0000", cycleStartDate: "2025-01-01", nextCycleStartDate: "2028-01-01", openingBalance: "30.0000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "30.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true }
        ]
      },
      {
        id: "cat_family",
        categoryName: "Family Leave",
        rules: [
          { id: "fam_1", description: "Family Leave first year", entitlementPerCycle: "3.0000", cycleStartDate: "2013-05-01", nextCycleStartDate: "", openingBalance: "0.0000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "0.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true },
          { id: "fam_2", description: "Family Leave", entitlementPerCycle: "3.0000", cycleStartDate: "2025-01-01", nextCycleStartDate: "2026-01-01", openingBalance: "3.0000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "3.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true }
        ]
      },
      {
        id: "cat_maternity",
        categoryName: "Maternity Leave",
        rules: [
          { id: "mat_1", description: "Maternity Leave", entitlementPerCycle: "0.0000", cycleStartDate: "", nextCycleStartDate: "", openingBalance: "0.00000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "0.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true }
        ]
      },
      {
        id: "cat_parental",
        categoryName: "Parental Leave",
        rules: [
          { id: "par_1", description: "Parental Leave", entitlementPerCycle: "0.0000", cycleStartDate: "", nextCycleStartDate: "", openingBalance: "0.00000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "0.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true }
        ]
      },
      {
        id: "cat_adoption",
        categoryName: "Adoption Leave",
        rules: [
          { id: "ado_1", description: "Adoption Leave", entitlementPerCycle: "0.0000", cycleStartDate: "", nextCycleStartDate: "", openingBalance: "0.00000", accrualThisPeriod: "0.0000", takenThisPeriod: "0.0000", closingBalance: "0.0000", plannedLeave: "0.0000", isEntitlementEditable: true, isCycleDateEditable: true }
        ]
      }
    ]
  });

  const handleUpdateRowRule = (categoryId: string, rowId: string, updatedFields: Partial<LeaveRowRule>) => {
    setProfile(prevProfile => {
      const updatedCategories = prevProfile.categories.map(category => {
        if (category.id !== categoryId) return category;
        
        const updatedRules = category.rules.map(row => {
          if (row.id !== rowId) return row;
          
          const mergedRow = { ...row, ...updatedFields };
          const opening = parseFloat(mergedRow.openingBalance) || 0;
          const accrual = parseFloat(mergedRow.accrualThisPeriod) || 0;
          const taken = parseFloat(mergedRow.takenThisPeriod) || 0;
          const currentClosing = (opening + accrual - taken).toFixed(4);

          return { ...mergedRow, closingBalance: currentClosing };
        });

        return { ...category, rules: updatedRules };
      });

      return { ...prevProfile, categories: updatedCategories };
    });
  };

  const handleWorkDayToggle = (day: string) => {
    setProfile(prev => ({
      ...prev,
      workDays: { ...prev.workDays, [day]: !prev.workDays[day] }
    }));
  };

  return (
    <div style={{ padding: "24px" }}>
      {/* Top Meta Header controls */}
      <div style={{ marginBottom: "20px" }}>
        <div style={{ display: "flex", gap: "10px", alignItems: "center", marginBottom: "15px" }}>
          <span style={{ fontSize: "14px" }}>The employee's leave start date is</span>
          <Input 
            type="text" 
            value={profile.leaveStartDate} 
            onChange={(e) => setProfile({ ...profile, leaveStartDate: e.target.value })}
            bsSize="sm"
            style={{ width: "140px", display: "inline-block" }} 
          />
          <Button color="success" size="sm" style={{ marginLeft: "auto", backgroundColor: "#4CAF50", border: "none" }}>Add New Transaction</Button>
        </div>

        <div style={{ display: "flex", gap: "15px", alignItems: "center", marginBottom: "15px", fontSize: "14px" }}>
          <span>This employee's leave is based on:</span>
          <Label style={{ margin: 0, display: "flex", alignItems: "center", gap: "5px" }}>
            <input 
              type="radio" 
              checked={profile.leaveBasis === "Working Days"} 
              onChange={() => setProfile({ ...profile, leaveBasis: "Working Days" })}
            /> Working Days
          </Label>
          <Label style={{ margin: 0, display: "flex", alignItems: "center", gap: "5px" }}>
            <input 
              type="radio" 
              checked={profile.leaveBasis === "Calendar Days"} 
              onChange={() => setProfile({ ...profile, leaveBasis: "Calendar Days" })}
            /> Calendar Days
          </Label>
        </div>

        <div style={{ display: "flex", gap: "15px", flexWrap: "wrap", alignItems: "center", fontSize: "14px", marginBottom: "25px" }}>
          <span>This employee works on:</span>
          {Object.keys(profile.workDays).map((day) => (
            <Label key={day} style={{ margin: 0, display: "flex", alignItems: "center", gap: "5px" }}>
              <input 
                type="checkbox" 
                checked={profile.workDays[day]} 
                onChange={() => handleWorkDayToggle(day)}
              /> {day}
            </Label>
          ))}
        </div>
      </div>

      {/* Categories tables container */}
      {profile.categories.map((category) => (
        <LeaveCategorySection 
          key={category.id} 
          category={category} 
          onUpdateRow={handleUpdateRowRule} 
        />
      ))}
      
      {/* Bottom Sticky Action Panel */}
      <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px", marginTop: "20px", borderTop: "1px solid #E2E8F0", paddingWidth: "100%", paddingTop: "15px" }}>
        <Button size="sm" style={{ backgroundColor: "#E0E0E0", color: "#333", border: "none" }}>Undo</Button>
        <Button size="sm" style={{ backgroundColor: "#E0E0E0", color: "#333", border: "none" }}>Save</Button>
      </div>
    </div>
  );
};

// ============================================
// MAIN ORGANIZATION SETTINGS PAGE (FULLY FIXED)
// ============================================
export const OrganizationSettingsPage = () => {
  const [activeTab, setActiveTab] = useState<"company" | "payroll" | "leave">("company");

  const tabStyle = (isActive: boolean) => ({
    padding: "12px 24px",
    backgroundColor: isActive ? "#33A6CD" : "transparent",
    color: isActive ? "white" : "#4A5568",
    border: "none",
    borderRadius: "8px 8px 0 0",
    cursor: "pointer",
    fontWeight: 500,
    transition: "all 0.2s ease",
    display: "flex",
    alignItems: "center",
    gap: "8px"
  });

  return (
    <div className="w-100" style={{ padding: "20px" }}>
      <div style={{ display: "flex", gap: "8px", borderBottom: "1px solid #E2E8F0", marginBottom: "24px" }}>
        <button onClick={() => setActiveTab("company")} style={tabStyle(activeTab === "company")}>
          <FaBuilding size={16} /> Company Details
        </button>
        <button onClick={() => setActiveTab("payroll")} style={tabStyle(activeTab === "payroll")}>
          <FaMoneyBillWave size={16} /> Payroll
        </button>
        <button onClick={() => setActiveTab("leave")} style={tabStyle(activeTab === "leave")}>
          <FaCalendarAlt size={16} /> Leave
        </button>
      </div>

      {activeTab === "company" && <CompanyDetailsTab />}
      {activeTab === "payroll" && <PayrollSettingsTab />}
      {activeTab === "leave" && <LeaveSettingsTab />}
    </div>
  );
};

export default OrganizationSettingsPage;